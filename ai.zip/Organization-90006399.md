# Asutus PÕHJA-EESTI REGIONAALHAIGLA - Tervisetõendi teenus (HCERT) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Asutus PÕHJA-EESTI REGIONAALHAIGLA**

## Example Organization: Asutus PÕHJA-EESTI REGIONAALHAIGLA

**name**: PÕHJA-EESTI REGIONAALHAIGLA



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "90006399",
  "name" : "PÕHJA-EESTI REGIONAALHAIGLA"
}

```
