# ee.fhir.hcert#1.0.0: Tervisetõendi teenus (HCERT)

## Pages

* [Sissejuhatus](index.md)
* [Allalaadimised](download.md)
* [Õigused API otspunktidele](permissions.md)
* [Juhend arendajale](dev.md)
* [Artifacts Summary](artifacts.md)
* [API kirjeldus](api.md)
* [Profiilid](profiles.md)

## Resources

### ValueSets

* [Tervisetõendi staatus (FHIR)](ValueSet-tervisetoendi-staatus-fhir--1.0.0.md)

### Resource Profiles

* [Tervisetõendi contained Observation](StructureDefinition-ee-health-certificate-contained-observation.md)
* [Otsus](StructureDefinition-ee-health-certificate-decision.md)
* [Mootosõidukijuhi tervisetõend](StructureDefinition-ee-health-certificate-driver.md)
* [Meditsiiniline piirang](StructureDefinition-ee-health-certificate-medical-restriction.md)
* [Töötervishoiu tervisekontrolli otsus tööandjale](StructureDefinition-ee-health-certificate-occupational-employer.md)
* [Töötamine](StructureDefinition-ee-health-certificate-occupational-employment.md)
* [Töötervishoiu tervisekontrolli otsus](StructureDefinition-ee-health-certificate-occupational.md)
* [Töötamiseks vajalik lisatingimus](StructureDefinition-ee-health-certificate-work-additional-condition.md)
* [Töölaadi ja töökeskkonnaga seotud ohutegurid](StructureDefinition-ee-health-certificate-work-related-risk-factor.md)
* [Tervisetõend](StructureDefinition-ee-health-certificate.md)

### ImplementationGuides

* [Tervisetõendi teenus (HCERT)](index.md)

### OperationDefinitions

* [Tervisetõendi tühistamine](OperationDefinition-ee-health-certificate-cancel.md)
* [Tervisetõendi ligipääsude päring](OperationDefinition-ee-health-certificate-get-consent.md)
* [Tervisetõendi PDF genereerimine](OperationDefinition-ee-health-certificate-pdf.md)
* [Tervisetõendi ligipääsude muutmine](OperationDefinition-ee-health-certificate-set-consent.md)
* [Tervisetõendi peatamine](OperationDefinition-ee-health-certificate-suspend.md)

### Examples

* [Töötervishoiu tervisekontrolli otsus (Composition)](Composition-1100.md)
* [Töötervishoiu tervisekontrolli otsus (Composition)](Composition-1110.md)
* [Mootorsõiduki juhtimise tervisetõend (Composition)](Composition-500.md)
* [PÕHJA-EESTI REGIONAALHAIGLA (Organization)](Organization-90006399.md)
* [200 (Patient)](Patient-200.md)
* [36109255737 (Practitioner)](Practitioner-36109255737.md)
* [100 (PractitionerRole)](PractitionerRole-100.md)
* [300 (QuestionnaireResponse)](QuestionnaireResponse-300.md)
