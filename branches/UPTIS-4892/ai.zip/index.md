# Sissejuhatus - Tervisetõendi teenus (HCERT) v1.0.0

* [**Table of Contents**](toc.md)
* **Sissejuhatus**

## Sissejuhatus

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/hcert/ImplementationGuide/ee.fhir.hcert | *Version*:1.0.0 |
| Active as of 2026-01-13 | *Computable Name*:HCERT |

### Sissejuhatus

HCERT (Health Certificate) ehk Tervisetõendi teenus on keskne rakendus, mille kaudu väljastatakse, säilitatakse ja hallatakse erinevate kasutusalade tervisetõendeid (näiteks töötervishoiu tõendid, mootorsõidukijui tõendid, relvaloa tõendid jpt.). Ülidsema tervisekontrolli digitaliseerimise projekti tutvustuse leiab lehelt: https://www.tehik.ee/tootervishoiu-tervisekontrolli-digitaliseerimine.

Käesoleval saidil kirjeldatakse HCERT rakendamisega seotud juurutusjuhendit. HCERT kasutab interaktsiooniprotokollina [FHIR standardit](http://fhir.hl7.org).

HCERT juurutusjuhend määratleb toetatud profiilide komplekti ja pakub iga profiili jaoks vähemalt ühe näite. FHIR profiili saab iseloomustada kui ühe fakti sisustusreeglistiku ning juurutusjuhendi kui kogumi sisustusreeglitest ja loenditest.

### Arendusvahendid ja lähtekood

HCERT-i juurutusjuhendi lähtekood on leitav [GitHubis](https://github.com/TEHIK-EE/ig-ee-hcert). Antud sait on välja töötatud [FHIR Shorthand](https://build.fhir.org/ig/HL7/fhir-shorthand) abiga. Täiendava informatsiooni FHIR Shorthand kohta saab leida [Confluence-is](https://confluence.hl7.org/display/FHIRI/FHIR+Shorthand), [GitHub-is](https://github.com/HL7/fhir-shorthand) ja [Zulip](https://chat.fhir.org) kanalis: #shorthand.

### IG metadata

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [EEHealthCertificate](StructureDefinition-ee-health-certificate.md), [EEHealthCertificateCancel](OperationDefinition-ee-health-certificate-cancel.md)...Show 15 more,[EEHealthCertificateContainedObservation](StructureDefinition-ee-health-certificate-contained-observation.md),[EEHealthCertificateDecision](StructureDefinition-ee-health-certificate-decision.md),[EEHealthCertificateDriver](StructureDefinition-ee-health-certificate-driver.md),[EEHealthCertificateDriverCategoryVS](ValueSet-ee-health-certificate-driver-category.md),[EEHealthCertificateGetConsent](OperationDefinition-ee-health-certificate-get-consent.md),[EEHealthCertificateMedicalRestriction](StructureDefinition-ee-health-certificate-medical-restriction.md),[EEHealthCertificateOccupational](StructureDefinition-ee-health-certificate-occupational.md),[EEHealthCertificateOccupationalEmployer](StructureDefinition-ee-health-certificate-occupational-employer.md),[EEHealthCertificateOccupationalEmployment](StructureDefinition-ee-health-certificate-occupational-employment.md),[EEHealthCertificatePdf](OperationDefinition-ee-health-certificate-pdf.md),[EEHealthCertificateSetConsent](OperationDefinition-ee-health-certificate-set-consent.md),[EEHealthCertificateSuspend](OperationDefinition-ee-health-certificate-suspend.md),[EEHealthCertificateWorkAdditionalCondition](StructureDefinition-ee-health-certificate-work-additional-condition.md),[EEHealthCertificateWorkRelatedRiskFactor](StructureDefinition-ee-health-certificate-work-related-risk-factor.md)and[HCERT](index.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [Composition/1100](Composition-1100.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* SNOMED Clinical Terms&reg; (SNOMED CT&reg;): [Composition/1100](Composition-1100.md), [Composition/500](Composition-500.md)...Show 9 more,[EEHealthCertificate](StructureDefinition-ee-health-certificate.md),[EEHealthCertificateDecision](StructureDefinition-ee-health-certificate-decision.md),[EEHealthCertificateDriver](StructureDefinition-ee-health-certificate-driver.md),[EEHealthCertificateMedicalRestriction](StructureDefinition-ee-health-certificate-medical-restriction.md),[EEHealthCertificateOccupational](StructureDefinition-ee-health-certificate-occupational.md),[EEHealthCertificateOccupationalEmployer](StructureDefinition-ee-health-certificate-occupational-employer.md),[EEHealthCertificateOccupationalEmployment](StructureDefinition-ee-health-certificate-occupational-employment.md),[EEHealthCertificateWorkAdditionalCondition](StructureDefinition-ee-health-certificate-work-additional-condition.md)and[EEHealthCertificateWorkRelatedRiskFactor](StructureDefinition-ee-health-certificate-work-related-risk-factor.md)





*There are no Global profiles defined*

